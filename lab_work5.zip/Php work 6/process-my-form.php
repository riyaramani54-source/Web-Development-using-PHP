<?
$the_password = $_GET['password'];

if ($the_password == 'secret') {
	echo'Yep, that is good!';
} else {
	echo 'Invalid password!';
}
?>