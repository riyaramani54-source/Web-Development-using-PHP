<?php

//echo "<pre>";
//print_r($_POST);
//echo "</pre>";

$username = $_POST[ ' user ' ];
$password = $_POST[ ' pass ' ];

if($username == "Admin" && $password == "1234") {
	//echo "Welcome Admin";
	header("location:dashboard.php");
	exit();
} else {
	echo "Wrong Username or Password";
}

?>
